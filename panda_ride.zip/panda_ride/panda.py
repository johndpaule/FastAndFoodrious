from ast import arg
import pygame, sys, random, argparse

def draw_floor():
	screen.blit(floor_surface,(floor_x_position,720))
	screen.blit(floor_surface,(floor_x_position + 576,720))

def create_pipe(pipe_level):
	random_pipe_position = random.choice(pipe_height)
	bottom_pipe = pipe_surface.get_rect(midtop = (1500,random_pipe_position+pipe_level))
	top_pipe = pipe_surface.get_rect(midtop = (1500,random_pipe_position+pipe_level))
	return bottom_pipe, top_pipe

def move_pipes(pipes):
	for pipe in pipes:
		pipe.centerx -= 5
	return pipes

def draw_pipes(pipes):
	for pipe in pipes:
		if pipe.bottom >= 1024:
			screen.blit(pipe_surface, pipe)
		# else:
		# 	flip_pipe = pygame.transform.flip(pipe_surface, False, True)
		# 	screen.blit(flip_pipe, pipe)

def check_collision(pipes):
	for pipe in pipes:
		if panda_rectangle.colliderect(pipe):
			death_sound.play()
			return False


	if panda_rectangle.top <= -100:
		print("collision")
		return False

	return True

def rotate_panda(panda):
	new_panda = pygame.transform.rotozoom(panda, 0, 1)
	return new_panda

def panda_animation():
	new_panda = panda_frames[panda_index]
	new_panda_rectangle = new_panda.get_rect(center = (100, panda_rectangle.centery))
	return new_panda, new_panda_rectangle

def score_display(game_state):
	if game_state == 'main_game':
		score_surface = game_font.render(f'Score: {int(score)}', True, (255,255,255))
		score_rectangle = score_surface.get_rect(center = (288, 100))
		screen.blit(score_surface, score_rectangle)

	if game_state == 'game_over':
		score_surface = game_font.render(f'Score: {int(score)}', True, (255,255,255))
		score_rectangle = score_surface.get_rect(center = (window_size_width / 2, 100))
		screen.blit(score_surface, score_rectangle)

		high_score_surface = game_font.render(f'High Score: {int(high_score)}', True, (255,255,255))
		high_score_rectangle = high_score_surface.get_rect(center = (window_size_width / 2, 185))
		screen.blit(high_score_surface, high_score_rectangle)

def update_score(score, high_score):
	if score > high_score:
		high_score = score
	return high_score

def starting_point():
	panda_rectangle.center = (100, 650)

#SET LEVEL
parser = argparse.ArgumentParser()
parser.add_argument('--level', nargs='?', default='hard', type=str, help='level', required=False)
args = parser.parse_args()
level = args.level
pipe_level_object = {
	'easy': 300,
	'medium': 150,
	'hard': -50,
}
pipe_level = pipe_level_object[level]

#function to initialize (init()) pygame
pygame.mixer.pre_init(frequency = 44100, size = 16, channels = 1, buffer = 512)
pygame.init()
# window_size = pygame.display.get_desktop_sizes()
window_size_width = 1536
screen = pygame.display.set_mode((window_size_width,864))
clock = pygame.time.Clock()
game_font = pygame.font.Font('04B_19.ttf',40)

# variables for the game
gravity = 0.23
panda_movement = 0
game_active = True
score = 0
high_score = 0

# this one would also work
# background_surface = pygame.transform.scale2x(pygame.image.load('assets/background-day.png'))

bg = ['assets/gamebg.png', 'assets/gamebg.png']
background_surface = pygame.image.load(random.choice(bg)).convert()
# background_surface = pygame.transform.scale2x(background_surface)
background_surface = pygame.transform.scale(background_surface, (window_size_width, 864))

floor_surface = pygame.image.load('assets/base.png').convert()
floor_surface = pygame.transform.scale2x(floor_surface)
floor_x_position = 0

panda_downflap = pygame.transform.scale2x(pygame.image.load('assets/panda-rider.png').convert_alpha())
panda_midflap = pygame.transform.scale2x(pygame.image.load('assets/panda-rider.png').convert_alpha())
panda_upflap = pygame.transform.scale2x(pygame.image.load('assets/panda-rider.png').convert_alpha())
panda_frames = [panda_downflap, panda_midflap, panda_upflap]
panda_index = 0
panda_surface = panda_frames[panda_index]
panda_rectangle = panda_surface.get_rect(center = (100,650))

is_jump = True

PANDARIDE = pygame.USEREVENT + 1
pygame.time.set_timer(PANDARIDE, 200)

# panda_surface = pygame.image.load('assets/panda-midflap.png').convert_alpha()
# panda_surface = pygame.transform.scale2x(panda_surface)
# panda_rectangle = panda_surface.get_rect(center = (100,512))

r_pipe = ['assets/pipe-green.png', 'assets/pipe-red.png']
pipe_surface = pygame.image.load(random.choice(r_pipe))
pipe_surface = pygame.transform.scale2x(pipe_surface)
pipe_list = []
SPAWNPIPE = pygame.USEREVENT
pygame.time.set_timer(SPAWNPIPE, 1200) # event triggered every 1.2 seconds
pipe_height = [550, 600, 700]

game_over_surface = pygame.image.load('assets/message.png').convert_alpha()
game_over_rectangle = game_over_surface.get_rect(center = (window_size_width / 2, 512))

flap_sound = pygame.mixer.Sound('sound/sfx_wing.wav')
death_sound = pygame.mixer.Sound('sound/sfx_hit.wav')
score_sound = pygame.mixer.Sound('sound/sfx_point.wav')
score_sound_countdown = 100


while True:
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			pygame.quit()
			sys.exit()

		if event.type == pygame.KEYDOWN:
			if event.key == pygame.K_SPACE and game_active and is_jump:
				panda_movement = 0
				panda_movement -= 12

				if panda_rectangle.bottom > 721:
					starting_point()
					gravity = 0.20
					is_jump = True
				else:
					gravity = 0.20
					is_jump = False
					
				flap_sound.play()
 
			if event.key == pygame.K_SPACE and game_active == False:
				game_active = True
				pipe_list.clear()
				starting_point()
				panda_movement = 1
				score = 0

		if event.type == SPAWNPIPE:
			pipe_list.extend(create_pipe(pipe_level))

		if event.type == PANDARIDE:
			if panda_index < 2:
				panda_index += 1
			else:
				panda_index = 0

			panda_surface, panda_rectangle = panda_animation()

	screen.blit(background_surface,(0,0))

	if game_active:
		# panda movement

		is_jump = False
		if panda_rectangle.bottom > 721:
			gravity = 0
			is_jump = True
			starting_point()

		panda_movement += gravity
		rotated_panda = rotate_panda(panda_surface)
		panda_rectangle.centery += panda_movement
		screen.blit(rotated_panda, panda_rectangle)
		game_active = check_collision(pipe_list)


		# pipes
		pipe_list = move_pipes(pipe_list)
		draw_pipes(pipe_list)

		score += 0.01
		score_display('main_game')
		score_sound_countdown -= 1
		if score_sound_countdown <= 0:
			score_sound.play()
			score_sound_countdown = 100

	else:
		screen.blit(game_over_surface, game_over_rectangle)
		high_score = update_score(score, high_score)
		score_display('game_over')


	#Floor
	floor_x_position -= 1
	# draw_floor()
	if floor_x_position <= -576:
		floor_x_position = 0


	pygame.display.update()
	clock.tick(120)  

